function a = acsc(a)
%ACSC         Hessian inverse cosecans  acsc(a)
%

% written  10/07/12     S.M. Rump
%

  a = asin(1./a);
  