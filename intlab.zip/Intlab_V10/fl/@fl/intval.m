function A = intval(A)
%INTVAL       Type cast fl-type to intval
%
%  B = intval(A)
%

% written  10/21/13     S.M. Rump
%

  A.value = intval(A.value);
  