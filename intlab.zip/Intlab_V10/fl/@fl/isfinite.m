function r = isfinite(A)
%ISFINITE     Array of 1's for finite components
%
%   r = isfinite(A)
%

% written  10/21/13     S.M. Rump
%

  r = isfinite(A.value) ;

