function A = abs(A)
%ABS          Absolute value for fl-type
%
%  f = abs(f)
%

% written  10/21/13  S.M. Rump
%

  A.value = abs(A.value);

  