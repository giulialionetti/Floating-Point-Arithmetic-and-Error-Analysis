function c = spones(A)
%SPONES       Implements  spones(a)  for sparse fl-type interval matrix
%
%   c = spones(A)
%

% written  11/07/13     S.M. Rump
%

  c = spones(A.value);
