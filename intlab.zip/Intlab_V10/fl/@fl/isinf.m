function r = isinf(A)
%ISINF        Array of 1's for infinite components
%
%   r = isinf(A)
%

% written  10/21/13     S.M. Rump
%

  r = isinf(A.value) ;

