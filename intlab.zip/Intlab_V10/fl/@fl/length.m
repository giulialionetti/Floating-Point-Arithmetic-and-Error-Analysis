function m = length(A)
%LENGTH       Implements  length(a)  for fl-type
%
%   m = length(A)
%

% written  10/21/13     S.M. Rump
%

  m = length(A.value);
