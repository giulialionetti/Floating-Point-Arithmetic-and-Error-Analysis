function A = uplus(A)
%UPLUS        Implements  +f  for fl-type
%

% written  10/21/13  S.M. Rump
%
