function r = ldivide(a,b)
%LDIVIDE      Gradient elementwise left division a .\ b
%

% written  11/02/05     S.M. Rump
%

  r = b ./ a;
