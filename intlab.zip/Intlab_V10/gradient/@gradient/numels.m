function n = numels(a)
%NUMELS       Number of elements
%
%  n = numels(a)
%

% written  12/12/15     S.M. Rump
%

  n = numels(a.x);
  
end  % function numels
