function res = iszero(a)
%ISZERO         Array of 1's for zero components
%
%   res = iszero(a)
%

% written  08/03/14  S.M. Rump
%

  res = iszero(intval(a));
  