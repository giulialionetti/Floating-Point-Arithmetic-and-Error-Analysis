function res = in(a,b)
%IN           Implements  a in b  entrywise for affaris a and b
%

% written  08/03/14  S.M. Rump
%

  res = in(intval(a),intval(b));
  