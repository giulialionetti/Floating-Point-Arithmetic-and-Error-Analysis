function r = sec(a)
%SEC          Affine arithmetic elementwise secans  sec(a)
%

% written  03/31/14     S.M. Rump
%

  r = 1./cos(a);
  