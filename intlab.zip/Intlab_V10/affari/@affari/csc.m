function r = csc(a)
%CSC          Affine arithmetic elementwise cosecans  csc(a)
%

% written  03/31/14     S.M. Rump
%

  r = 1./sin(a);
  