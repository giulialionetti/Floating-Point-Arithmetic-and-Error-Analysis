function c = mag(a)
%MAG          Absolute value for affine arithmetic
%
%  c = mag(a);
%

% written  03/08/14     S.M. Rump
%

  c = mag(a.range);
