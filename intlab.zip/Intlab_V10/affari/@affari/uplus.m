function a = uplus(a)
%UPLUS        Affine arithmetic monadic plus  + a
%

% written  12/06/13  S.M. Rump
%
