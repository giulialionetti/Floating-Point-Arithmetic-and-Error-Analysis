function res = isintval(a)
%ISINTVAL     returns 0 because  a  is affari
%
%   res = isintval(a)
%

% written  08/03/14     S.M. Rump
% modified 05/17/14     S.M. Rump  code optimization
%

  res = false;
  