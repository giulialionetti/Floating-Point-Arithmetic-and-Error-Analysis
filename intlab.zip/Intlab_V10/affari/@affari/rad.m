function r = rad(a)
%RAD          Radius of affine arithmetic
%
%   r = rad(a)
%

% written  12/06/13  S.M. Rump
%

  r = rad(a.range);
