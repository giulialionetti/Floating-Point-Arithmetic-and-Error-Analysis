function res = compmat(a)
%COMPMAT      Comparison matrix for affari matrices
%
%   Ac = compmat(A)
%

% written  08/09/02     S.M. Rump 
% modified 05/17/14     S.M. Rump  code optimization
%

  res = compmat(intval(a));
  