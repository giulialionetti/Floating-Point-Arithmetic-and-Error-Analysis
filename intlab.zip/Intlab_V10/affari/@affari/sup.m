function r = sup(a)
%SUP          Upper bound for affine arithmetic
%
%   r = sup(a)
%

% written  12/06/13  S.M. Rump
%

  r = sup(intval(a));
  