function r = asec(a)
%ASEC         Affine arithmetic elementwise inverse secans  asec(a)
%

% written  03/31/14     S.M. Rump
%

  r = acos(1./a);
  