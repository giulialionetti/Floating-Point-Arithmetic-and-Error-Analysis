function r = minus(a,b)
%MINUS        Affine arithmetic subtraction  a - b
%

% written  12/06/13  S.M. Rump
%

  r = a + (-b);
  