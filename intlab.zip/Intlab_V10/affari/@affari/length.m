function res = length(a)
%LENGTH        Implements  length(a)  for affaris
% 
%    m = length(a)
%

% written  08/09/02     S.M. Rump 
% modified 05/17/14     S.M. Rump  code optimization
%

  res = length(a.range);
  