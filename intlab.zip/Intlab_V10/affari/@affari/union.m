function union(varargin)
%UNION        For interval union, please use "hull"
%

% written  08/09/02     S.M. Rump 
% modified 05/17/14     S.M. Rump  code optimization
%

  error('For interval union, please use "hull".')
  